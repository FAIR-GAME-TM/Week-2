
function myFunction(){
    document.getElementById("Javascript").innerHTML = "You Loose";
    alert("You did not win, and this is my first time coding, thank you prof battana and levi");
}
